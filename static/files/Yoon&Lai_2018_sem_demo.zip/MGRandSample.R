MGRandSample <- function(datfile, group_col = NULL, nsam = 100) {
  # datfile: path for raw data file (to be read using `read.table` in R)
  # group_col: location of the column containing the grouping variable
  # nsam: number of random samples drawn
  dat <- read.table(datfile)
  if (is.null(group_col)) {
    group_col <- readline(paste("Input the column containing",
                                "the grouping variable, then hit Return: "))
    group_col <- as.numeric(group_col)
  }
  id <- dat[ , group_col]
  min_n <- min(table(id))
  max_n <- max(table(id))
  if (max_n == min_n) stop("Balanced Design; No sampling needed")
  ids <- split(seq_along(id), id)
  sam_dir <- file.path(dirname(tools::file_path_as_absolute(datfile)), 
                       "new_data")
  dir.create(sam_dir)
  dat_basename <- basename(tools::file_path_sans_ext(datfile))
  sam_names <- paste0(dat_basename, "tmp_", seq_len(nsam), ".dat")
  sam_paths <- file.path(sam_dir, sam_names)
  for (i in seq_len(nsam)) {
    new_id <- unlist(lapply(ids, sample, min_n))
    dat_sam <- dat[new_id, ]
    write.table(dat_sam, sam_paths[i], 
                row.names = F, col.names = F)
  }
  listfile_path <- file.path(sam_dir, paste0(dat_basename, "tmp_list.dat"))
  write(sam_names, listfile_path)
  cat("Sampled data sets saved at", sam_dir, "\n")
  cat("Replace the `DATA` part in your Mplus syntax with the following two lines:", 
      "\n\nDATA:   File =", listfile_path, ";
        Type = montecarlo;\n")
}

MGRandSample(file.choose(), nsam = 100)  # May take about a minute